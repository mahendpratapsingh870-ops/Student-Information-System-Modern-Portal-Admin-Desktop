package com.studentinfo.repository;

import com.studentinfo.entity.Attendance;
import com.studentinfo.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByStudent(Student student);
    List<Attendance> findByStudentAndAttendanceDateBetween(Student student, String startDate, String endDate);
}
