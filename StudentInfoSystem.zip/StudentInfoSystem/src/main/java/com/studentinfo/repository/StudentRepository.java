package com.studentinfo.repository;

import com.studentinfo.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    Optional<Student> findByEmail(String email);
    Optional<Student> findByEnrollmentNumber(String enrollmentNumber);
    List<Student> findByIsActiveTrue();
    boolean existsByEmail(String email);
    boolean existsByEnrollmentNumber(String enrollmentNumber);
}
