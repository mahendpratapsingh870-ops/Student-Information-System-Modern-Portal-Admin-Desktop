package com.studentinfo.repository;

import com.studentinfo.entity.Marks;
import com.studentinfo.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MarksRepository extends JpaRepository<Marks, Long> {
    List<Marks> findByStudent(Student student);
    List<Marks> findByStudentAndSubject(Student student, String subject);
}
