package com.studentinfo.service;

import com.studentinfo.entity.Admin;
import com.studentinfo.repository.AdminRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final AdminRepository adminRepository;

    public Admin registerAdmin(String firstName, String lastName, String email, String password) {
        if (adminRepository.existsByEmail(email)) {
            throw new RuntimeException("Email already exists");
        }

        Admin admin = Admin.builder()
                .firstName(firstName)
                .lastName(lastName)
                .email(email)
                .password(password)
                .role("ADMIN")
                .isActive(true)
                .build();

        return adminRepository.save(admin);
    }

    public Optional<Admin> loginAdmin(String email, String password) {
        Optional<Admin> admin = adminRepository.findByEmail(email);
        if (admin.isPresent() && admin.get().getPassword().equals(password)) {
            return admin;
        }
        return Optional.empty();
    }

    public Admin getAdminById(Long adminId) {
        return adminRepository.findById(adminId)
                .orElseThrow(() -> new RuntimeException("Admin not found"));
    }

    public Admin updateAdmin(Long adminId, String firstName, String lastName) {
        Admin admin = getAdminById(adminId);
        admin.setFirstName(firstName);
        admin.setLastName(lastName);
        return adminRepository.save(admin);
    }

    public void deleteAdmin(Long adminId) {
        Admin admin = getAdminById(adminId);
        admin.setIsActive(false);
        adminRepository.save(admin);
    }

    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }
}
