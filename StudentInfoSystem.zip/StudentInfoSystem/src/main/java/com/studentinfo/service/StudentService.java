package com.studentinfo.service;

import com.studentinfo.dto.StudentDTO;
import com.studentinfo.entity.Student;
import com.studentinfo.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;

    public Student registerStudent(StudentDTO studentDTO) {
        if (studentRepository.existsByEmail(studentDTO.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        if (studentRepository.existsByEnrollmentNumber(studentDTO.getEnrollmentNumber())) {
            throw new RuntimeException("Enrollment number already exists");
        }

        Student student = Student.builder()
                .firstName(studentDTO.getFirstName())
                .lastName(studentDTO.getLastName())
                .email(studentDTO.getEmail())
                .phone(studentDTO.getPhone())
                .password(studentDTO.getPassword())
                .enrollmentNumber(studentDTO.getEnrollmentNumber())
                .dateOfBirth(studentDTO.getDateOfBirth())
                .address(studentDTO.getAddress())
                .totalMarks(0.0)
                .attendancePercentage(0)
                .isActive(true)
                .build();

        return studentRepository.save(student);
    }

    public Optional<Student> loginStudent(String email, String password) {
        Optional<Student> student = studentRepository.findByEmail(email);
        if (student.isPresent() && student.get().getPassword().equals(password)) {
            return student;
        }
        return Optional.empty();
    }

    public Student getStudentById(Long studentId) {
        return studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
    }

    public Student updateStudent(Long studentId, StudentDTO studentDTO) {
        Student student = getStudentById(studentId);
        
        student.setFirstName(studentDTO.getFirstName());
        student.setLastName(studentDTO.getLastName());
        student.setPhone(studentDTO.getPhone());
        student.setAddress(studentDTO.getAddress());
        student.setDateOfBirth(studentDTO.getDateOfBirth());

        return studentRepository.save(student);
    }

    public void deleteStudent(Long studentId) {
        Student student = getStudentById(studentId);
        student.setIsActive(false);
        studentRepository.save(student);
    }

    public List<Student> getAllActiveStudents() {
        return studentRepository.findByIsActiveTrue();
    }

    public List<StudentDTO> getAllStudentsDTO() {
        return studentRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public StudentDTO getStudentDTOById(Long studentId) {
        return convertToDTO(getStudentById(studentId));
    }

    private StudentDTO convertToDTO(Student student) {
        return StudentDTO.builder()
                .studentId(student.getStudentId())
                .firstName(student.getFirstName())
                .lastName(student.getLastName())
                .email(student.getEmail())
                .phone(student.getPhone())
                .enrollmentNumber(student.getEnrollmentNumber())
                .dateOfBirth(student.getDateOfBirth())
                .address(student.getAddress())
                .totalMarks(student.getTotalMarks())
                .attendancePercentage(student.getAttendancePercentage())
                .isActive(student.getIsActive())
                .enrollmentDate(student.getEnrollmentDate())
                .build();
    }

    public void updateStudentMarks(Long studentId, Double totalMarks) {
        Student student = getStudentById(studentId);
        student.setTotalMarks(totalMarks);
        studentRepository.save(student);
    }

    public void updateAttendancePercentage(Long studentId, Integer percentage) {
        Student student = getStudentById(studentId);
        student.setAttendancePercentage(percentage);
        studentRepository.save(student);
    }
}
