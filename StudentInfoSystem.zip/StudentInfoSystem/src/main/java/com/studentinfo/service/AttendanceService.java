package com.studentinfo.service;

import com.studentinfo.entity.Attendance;
import com.studentinfo.entity.Student;
import com.studentinfo.repository.AttendanceRepository;
import com.studentinfo.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;
    private final StudentService studentService;

    public Attendance markAttendance(Long studentId, String attendanceDate, Boolean isPresent, String remarks) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        Attendance attendance = Attendance.builder()
                .student(student)
                .attendanceDate(attendanceDate)
                .isPresent(isPresent)
                .remarks(remarks)
                .build();

        Attendance saved = attendanceRepository.save(attendance);
        updateStudentAttendancePercentage(studentId);
        return saved;
    }

    public List<Attendance> getAttendanceByStudent(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        return attendanceRepository.findByStudent(student);
    }

    public Attendance updateAttendance(Long attendanceId, Boolean isPresent, String remarks) {
        Attendance attendance = attendanceRepository.findById(attendanceId)
                .orElseThrow(() -> new RuntimeException("Attendance not found"));

        attendance.setIsPresent(isPresent);
        attendance.setRemarks(remarks);
        Attendance updated = attendanceRepository.save(attendance);
        updateStudentAttendancePercentage(attendance.getStudent().getStudentId());
        return updated;
    }

    public void deleteAttendance(Long attendanceId) {
        Attendance attendance = attendanceRepository.findById(attendanceId)
                .orElseThrow(() -> new RuntimeException("Attendance not found"));
        Long studentId = attendance.getStudent().getStudentId();
        attendanceRepository.deleteById(attendanceId);
        updateStudentAttendancePercentage(studentId);
    }

    public Attendance getAttendanceById(Long attendanceId) {
        return attendanceRepository.findById(attendanceId)
                .orElseThrow(() -> new RuntimeException("Attendance not found"));
    }

    public List<Attendance> getAllAttendance() {
        return attendanceRepository.findAll();
    }

    private void updateStudentAttendancePercentage(Long studentId) {
        List<Attendance> allAttendance = getAttendanceByStudent(studentId);
        if (allAttendance.isEmpty()) {
            studentService.updateAttendancePercentage(studentId, 0);
            return;
        }

        long presentCount = allAttendance.stream()
                .filter(Attendance::getIsPresent)
                .count();

        int percentage = (int) ((presentCount * 100) / allAttendance.size());
        studentService.updateAttendancePercentage(studentId, percentage);
    }
}
