package com.studentinfo.service;

import com.studentinfo.entity.Marks;
import com.studentinfo.entity.Student;
import com.studentinfo.repository.MarksRepository;
import com.studentinfo.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MarksService {

    private final MarksRepository marksRepository;
    private final StudentRepository studentRepository;
    private final StudentService studentService;

    public Marks addMarks(Long studentId, String subject, Double marksObtained, String examDate, String examType) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        Marks marks = Marks.builder()
                .student(student)
                .subject(subject)
                .marksObtained(marksObtained)
                .totalMarks(100.0)
                .examDate(examDate)
                .examType(examType)
                .build();

        Marks savedMarks = marksRepository.save(marks);
        updateStudentTotalMarks(studentId);
        return savedMarks;
    }

    public List<Marks> getMarksByStudent(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        return marksRepository.findByStudent(student);
    }

    public Marks updateMarks(Long marksId, Double marksObtained) {
        Marks marks = marksRepository.findById(marksId)
                .orElseThrow(() -> new RuntimeException("Marks not found"));

        marks.setMarksObtained(marksObtained);
        Marks updated = marksRepository.save(marks);
        updateStudentTotalMarks(marks.getStudent().getStudentId());
        return updated;
    }

    public void deleteMarks(Long marksId) {
        Marks marks = marksRepository.findById(marksId)
                .orElseThrow(() -> new RuntimeException("Marks not found"));
        Long studentId = marks.getStudent().getStudentId();
        marksRepository.deleteById(marksId);
        updateStudentTotalMarks(studentId);
    }

    public Marks getMarkById(Long marksId) {
        return marksRepository.findById(marksId)
                .orElseThrow(() -> new RuntimeException("Marks not found"));
    }

    public List<Marks> getAllMarks() {
        return marksRepository.findAll();
    }

    private void updateStudentTotalMarks(Long studentId) {
        List<Marks> allMarks = getMarksByStudent(studentId);
        Double averageMarks = allMarks.stream()
                .mapToDouble(Marks::getMarksObtained)
                .average()
                .orElse(0.0);
        studentService.updateStudentMarks(studentId, averageMarks);
    }
}
