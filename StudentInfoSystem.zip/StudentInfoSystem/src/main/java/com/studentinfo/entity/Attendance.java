package com.studentinfo.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "attendance")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Attendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long attendanceId;

    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @Column(nullable = false)
    private String attendanceDate;

    @Column(nullable = false)
    private Boolean isPresent;

    private String remarks;

    @Column(nullable = false)
    @Builder.Default
    private String recordedDate = java.time.LocalDate.now().toString();
}
