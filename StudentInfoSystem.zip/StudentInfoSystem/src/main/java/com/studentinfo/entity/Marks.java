package com.studentinfo.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "marks")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Marks {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long marksId;

    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @NotBlank(message = "Subject is required")
    @Column(nullable = false)
    private String subject;

    @NotNull(message = "Marks obtained is required")
    @Min(value = 0, message = "Marks should be at least 0")
    @Max(value = 100, message = "Marks should not exceed 100")
    @Column(nullable = false)
    private Double marksObtained;

    @Column(nullable = false)
    @Builder.Default
    private Double totalMarks = 100.0;

    @Column(nullable = false)
    private String examDate;

    private String examType;

    @Column(nullable = false)
    @Builder.Default
    private String recordedDate = java.time.LocalDate.now().toString();
}
