package com.studentinfo.controller;

import com.studentinfo.dto.ApiResponse;
import com.studentinfo.entity.Attendance;
import com.studentinfo.service.AttendanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/attendance")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping("/mark")
    public ResponseEntity<ApiResponse<Attendance>> markAttendance(@RequestBody Map<String, Object> request) {
        try {
            Long studentId = Long.valueOf(request.get("studentId").toString());
            String attendanceDate = request.get("attendanceDate").toString();
            Boolean isPresent = Boolean.valueOf(request.get("isPresent").toString());
            String remarks = request.getOrDefault("remarks", "").toString();

            Attendance attendance = attendanceService.markAttendance(studentId, attendanceDate, isPresent, remarks);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Attendance marked successfully", attendance, 201));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<ApiResponse<List<Attendance>>> getAttendanceByStudent(@PathVariable Long studentId) {
        try {
            List<Attendance> attendance = attendanceService.getAttendanceByStudent(studentId);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Attendance retrieved successfully", attendance, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage(), 404));
        }
    }

    @GetMapping("/{attendanceId}")
    public ResponseEntity<ApiResponse<Attendance>> getAttendanceById(@PathVariable Long attendanceId) {
        try {
            Attendance attendance = attendanceService.getAttendanceById(attendanceId);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Attendance retrieved successfully", attendance, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage(), 404));
        }
    }

    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<Attendance>>> getAllAttendance() {
        try {
            List<Attendance> attendance = attendanceService.getAllAttendance();
            return ResponseEntity.ok()
                    .body(ApiResponse.success("All attendance retrieved", attendance, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @PutMapping("/{attendanceId}")
    public ResponseEntity<ApiResponse<Attendance>> updateAttendance(
            @PathVariable Long attendanceId,
            @RequestBody Map<String, Object> request) {
        try {
            Boolean isPresent = Boolean.valueOf(request.get("isPresent").toString());
            String remarks = request.getOrDefault("remarks", "").toString();
            Attendance attendance = attendanceService.updateAttendance(attendanceId, isPresent, remarks);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Attendance updated successfully", attendance, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @DeleteMapping("/{attendanceId}")
    public ResponseEntity<ApiResponse<String>> deleteAttendance(@PathVariable Long attendanceId) {
        try {
            attendanceService.deleteAttendance(attendanceId);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Attendance deleted successfully", null, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }
}
