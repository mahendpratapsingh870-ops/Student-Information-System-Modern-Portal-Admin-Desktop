package com.studentinfo.controller;

import com.studentinfo.dto.ApiResponse;
import com.studentinfo.entity.Marks;
import com.studentinfo.service.MarksService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/marks")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class MarksController {

    private final MarksService marksService;

    @PostMapping("/add")
    public ResponseEntity<ApiResponse<Marks>> addMarks(@RequestBody Map<String, Object> request) {
        try {
            Long studentId = Long.valueOf(request.get("studentId").toString());
            String subject = request.get("subject").toString();
            Double marksObtained = Double.valueOf(request.get("marksObtained").toString());
            String examDate = request.get("examDate").toString();
            String examType = request.get("examType").toString();

            Marks marks = marksService.addMarks(studentId, subject, marksObtained, examDate, examType);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Marks added successfully", marks, 201));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<ApiResponse<List<Marks>>> getMarksByStudent(@PathVariable Long studentId) {
        try {
            List<Marks> marks = marksService.getMarksByStudent(studentId);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Marks retrieved successfully", marks, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage(), 404));
        }
    }

    @GetMapping("/{marksId}")
    public ResponseEntity<ApiResponse<Marks>> getMarkById(@PathVariable Long marksId) {
        try {
            Marks marks = marksService.getMarkById(marksId);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Marks retrieved successfully", marks, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage(), 404));
        }
    }

    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<Marks>>> getAllMarks() {
        try {
            List<Marks> marks = marksService.getAllMarks();
            return ResponseEntity.ok()
                    .body(ApiResponse.success("All marks retrieved", marks, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @PutMapping("/{marksId}")
    public ResponseEntity<ApiResponse<Marks>> updateMarks(
            @PathVariable Long marksId,
            @RequestBody Map<String, Object> request) {
        try {
            Double marksObtained = Double.valueOf(request.get("marksObtained").toString());
            Marks marks = marksService.updateMarks(marksId, marksObtained);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Marks updated successfully", marks, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @DeleteMapping("/{marksId}")
    public ResponseEntity<ApiResponse<String>> deleteMarks(@PathVariable Long marksId) {
        try {
            marksService.deleteMarks(marksId);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Marks deleted successfully", null, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }
}
