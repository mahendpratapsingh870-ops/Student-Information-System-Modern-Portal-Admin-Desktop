package com.studentinfo.controller;

import com.studentinfo.dto.ApiResponse;
import com.studentinfo.dto.LoginDTO;
import com.studentinfo.dto.StudentDTO;
import com.studentinfo.entity.Student;
import com.studentinfo.service.StudentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/students")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class StudentController {

    private final StudentService studentService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<Student>> registerStudent(@Valid @RequestBody StudentDTO studentDTO) {
        try {
            Student student = studentService.registerStudent(studentDTO);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Student registered successfully", student, 201));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<Student>> loginStudent(@Valid @RequestBody LoginDTO loginDTO) {
        try {
            var student = studentService.loginStudent(loginDTO.getEmail(), loginDTO.getPassword());
            if (student.isPresent()) {
                return ResponseEntity.ok()
                        .body(ApiResponse.success("Login successful", student.get(), 200));
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(ApiResponse.error("Invalid email or password", 401));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<StudentDTO>> getStudentById(@PathVariable Long id) {
        try {
            StudentDTO student = studentService.getStudentDTOById(id);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Student retrieved successfully", student, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage(), 404));
        }
    }

    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<StudentDTO>>> getAllStudents() {
        try {
            List<StudentDTO> students = studentService.getAllStudentsDTO();
            return ResponseEntity.ok()
                    .body(ApiResponse.success("All students retrieved", students, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Student>> updateStudent(
            @PathVariable Long id,
            @Valid @RequestBody StudentDTO studentDTO) {
        try {
            Student student = studentService.updateStudent(id, studentDTO);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Student updated successfully", student, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<String>> deleteStudent(@PathVariable Long id) {
        try {
            studentService.deleteStudent(id);
            return ResponseEntity.ok()
                    .body(ApiResponse.success("Student deactivated successfully", null, 200));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.error(e.getMessage(), 400));
        }
    }
}
